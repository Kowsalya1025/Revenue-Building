# Revenue Intelligence Inbox

A sales-manager workspace for reviewing call and meeting activity, checking why a conversation was routed, correcting records, and exporting evidence-backed reviews.

## Demo and data handling

The first launch contains eight fictional calls. Their amounts, quotes, people, and findings are synthetic examples, not customer data. CSV imports and manual edits are stored in the current browser only; they are not uploaded or shared with other people who open the app. Use a clean browser profile for a fresh demo.

## Workflow

1. Review the dashboard and open a conversation to inspect the source quote behind its route.
2. Import a CSV with a stable `id` or `source_id` and an `account` or `company` column. Matching IDs update existing source values; unchanged rows are counted without duplication. Manual corrections are kept as overrides.
3. Correct a record or route from its detail view. The app keeps a local change history.
4. Export a filtered CSV or JSON and a manifest describing the exported records.

The supplied sample exports are in `public/exports/`. The editable application source is in `src/`.

## Import fields

Recognized columns include `id` / `source_id`, `source`, `date`, `type`, `duration_minutes`, `account` / `company`, `contact`, `rep` / `owner`, `deal_value` / `amount`, `stage`, `summary`, `transcript`, `next_step`, and `next_step_due`. The minimum required columns are a stable source ID and an account name.
