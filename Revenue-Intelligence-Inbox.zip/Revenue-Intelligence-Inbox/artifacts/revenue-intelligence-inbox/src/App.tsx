import { useMemo, useRef, useState, type ChangeEvent, type FormEvent, type ReactNode } from 'react';
import { Link, Route, Switch, useLocation } from 'wouter';
import {
  Activity, ArrowDownToLine, ArrowLeft, ArrowRight, BadgeCheck, BarChart3, CalendarDays,
  Check, CheckCheck, CircleHelp, Clock3, Download, FileJson, FileSpreadsheet, History, Inbox,
  LockKeyhole, MessageSquareQuote, Pencil, Plus, RotateCcw, Search, ShieldCheck, Sparkles, Upload, X,
} from 'lucide-react';
import {
  csvEscape, displayDate, formatMoney, previewCsv, useConversationStore,
  type Conversation, type ConversationStatus, type EditableFields, type Route as InboxRoute,
} from '@/lib/inbox';
import NotFound from '@/pages/not-found';

type Store = ReturnType<typeof useConversationStore>;
type PageProps = { records: Conversation[]; store: Store };
const routeTypes: InboxRoute[] = ['Specialist handoff', 'Immediate follow-up', 'Manager review', 'Monitor', 'Resolved'];

function routeClass(route: InboxRoute) {
  if (route === 'Specialist handoff') return 'route-specialist';
  if (route === 'Immediate follow-up') return 'route-immediate';
  if (route === 'Manager review') return 'route-manager';
  if (route === 'Resolved') return 'route-resolved';
  return 'route-monitor';
}
function RoutePill({ route }: { route: InboxRoute }) {
  return <span className={`route-pill ${routeClass(route)}`}>{route}</span>;
}
function StatusPill({ status }: { status: ConversationStatus }) {
  return <span className={`status-pill status-${status}`}>{status === 'handled' ? 'Handled' : status === 'queued' ? 'Queued' : 'Open'}</span>;
}
function PageTitle({ eyebrow, title, description, actions }: { eyebrow: string; title: string; description: string; actions?: ReactNode }) {
  return <div className="page-head"><div><div className="eyebrow">{eyebrow}</div><h1>{title}</h1><p className="page-intro">{description}</p></div>{actions && <div className="heading-actions">{actions}</div>}</div>;
}
function PanelTitle({ title, caption, right }: { title: string; caption?: string; right?: ReactNode }) {
  return <div className="panel-head"><div><h2 className="panel-title">{title}</h2>{caption && <p className="panel-caption">{caption}</p>}</div>{right}</div>;
}
function PrivacyBanner() {
  return <div className="privacy-banner"><LockKeyhole size={15} /><span><strong>Private by design.</strong> Conversation data and changes stay in this browser. Imports are not uploaded to a shared server.</span></div>;
}
function Shell({ children, count }: { children: ReactNode; count: number }) {
  const [location] = useLocation();
  const nav = [
    { href: '/', label: 'Review queue', icon: Inbox },
    { href: '/insights', label: 'Insights', icon: BarChart3 },
    { href: '/imports', label: 'Imports', icon: Upload },
    { href: '/exports', label: 'Exports', icon: ArrowDownToLine },
  ];
  return <div className="app-shell" style={{ display: 'flex' }}>
    <aside className="sidebar">
      <Link href="/" className="brand"><span className="brand-mark">R</span><span><span className="brand-name">Revenue signal</span><span className="brand-sub">Intelligence inbox</span></span></Link>
      <div className="nav-label">Workspace</div>
      <nav className="nav-list" aria-label="Main navigation">{nav.map(item => {
        const Icon = item.icon;
        const active = item.href === '/' ? location === '/' || location.startsWith('/conversation/') : location.startsWith(item.href);
        return <Link key={item.href} href={item.href} className={`nav-link ${active ? 'active' : ''}`}><Icon size={17} />{item.label}{item.href === '/' && count > 0 && <span className="nav-count">{count}</span>}</Link>;
      })}</nav>
      <div className="sidebar-foot"><div className="privacy-note"><strong><ShieldCheck size={14} /> Local-only workspace</strong>Your records live in this browser. No account or shared server required.</div></div>
    </aside>
    <main className="workspace"><header className="topbar"><div className="top-meta"><span className="sync-dot" /><span>All changes saved locally</span><span className="top-hidden">·</span><span className="top-hidden">Demo workspace</span></div><div className="top-meta"><span className="top-hidden">Sales leadership</span><span className="avatar">SL</span></div></header>{children}</main>
  </div>;
}

function ConversationTable({ records, store }: PageProps) {
  if (!records.length) return <div className="empty-state"><div className="empty-icon"><Search size={20} /></div><h3>No conversations match</h3><p>Try another search or clear the filters to see the full review queue.</p></div>;
  return <div className="table-wrap"><table className="conversation-table"><thead><tr><th>Conversation</th><th>Rep / meeting</th><th>Deal</th><th>Route & evidence</th><th>Status</th><th>Confidence</th><th aria-label="Actions" /></tr></thead><tbody>{records.map(record => <tr key={record.id} data-testid={`row-conversation-${record.id}`}>
    <td className="account-cell"><Link href={`/conversation/${encodeURIComponent(record.id)}`} className="account-name">{record.account}</Link><div className="subline">{record.contact} · {displayDate(record.date)} · {record.id}</div></td>
    <td><strong>{record.rep}</strong><div className="subline">{record.meetingType} · {record.durationMinutes} min</div></td>
    <td><strong>{formatMoney(record.dealValue, true)}</strong><div className="subline">{record.stage}</div></td>
    <td><RoutePill route={record.route} /><div className="subline">{record.routeEvidence[0]?.quote ? `“${record.routeEvidence[0].quote.slice(0, 52)}${record.routeEvidence[0].quote.length > 52 ? '…' : ''}”` : 'Rationale available'}</div></td>
    <td><StatusPill status={record.status} /></td>
    <td><span className="confidence"><i style={{ width: `${Math.round(record.confidence * 100)}%` }} /></span><span className="mono">{Math.round(record.confidence * 100)}%</span></td>
    <td><Link aria-label={`Open ${record.account}`} href={`/conversation/${encodeURIComponent(record.id)}`} className="table-action"><ArrowRight size={16} /></Link></td>
  </tr>)}</tbody></table></div>;
}

function Dashboard({ records, store }: PageProps) {
  const [query, setQuery] = useState('');
  const [routeFilter, setRouteFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('active');
  const filtered = useMemo(() => records.filter(record => {
    const needle = query.trim().toLowerCase();
    const textMatch = !needle || [record.account, record.contact, record.rep, record.summary, record.id, record.route].some(v => v.toLowerCase().includes(needle));
    return textMatch && (routeFilter === 'all' || record.route === routeFilter) &&
      (statusFilter === 'all' || (statusFilter === 'active' ? record.status !== 'handled' : record.status === statusFilter));
  }), [records, query, routeFilter, statusFilter]);
  const openCount = records.filter(record => record.status === 'open').length;
  const priority = records.filter(record => ['Specialist handoff', 'Immediate follow-up', 'Manager review'].includes(record.route) && record.status !== 'handled').length;
  const pipeline = records.reduce((total, record) => total + record.dealValue, 0);
  const due = records.filter(record => record.nextStepDue && record.nextStepDue <= '2026-10-23' && record.status !== 'handled').length;
  return <div className="page">
    <PageTitle eyebrow="Friday, October 23 · manager view" title="The signal, not the noise." description="A clear next move for every conversation that could change the quarter." actions={<><Link className="btn" href="/imports"><Upload size={15} /> Import calls</Link><Link className="btn primary" href="/exports"><Download size={15} /> Export review</Link></>} />
    <div className="metrics">
      <div className="metric"><div className="metric-label"><Inbox size={14} /> Open conversations</div><div className="metric-value">{openCount}</div><div className="metric-foot">Across {records.length} records in this workspace</div></div>
      <div className="metric"><div className="metric-label"><Activity size={14} /> Needs a decision</div><div className="metric-value">{priority}</div><div className="metric-foot">Specialist, urgent, or manager review</div></div>
      <div className="metric"><div className="metric-label"><CalendarDays size={14} /> Past-due next steps</div><div className="metric-value">{due}</div><div className="metric-foot">Due today or earlier · open records</div></div>
      <div className="metric"><div className="metric-label"><BarChart3 size={14} /> Pipeline in view</div><div className="metric-value">{formatMoney(pipeline, true)}</div><div className="metric-foot">Sum of current conversation deal values</div></div>
    </div>
    <PrivacyBanner />
    <section className="panel">
      <PanelTitle title="Review queue" caption={`${filtered.length} of ${records.length} conversations · evidence stays beside the route`} right={<span className="mono">SORTED BY SOURCE DATE</span>} />
      <div className="queue-toolbar">
        <label className="searchbox"><Search size={15} /><input className="input" aria-label="Search conversations" placeholder="Search account, rep, evidence…" value={query} onChange={e => setQuery(e.target.value)} data-testid="input-search" /></label>
        <select className="select filter-select" aria-label="Filter by route" value={routeFilter} onChange={e => setRouteFilter(e.target.value)} data-testid="filter-route"><option value="all">All routes</option>{routeTypes.map(route => <option key={route}>{route}</option>)}</select>
        <select className="select filter-select" aria-label="Filter by status" value={statusFilter} onChange={e => setStatusFilter(e.target.value)} data-testid="filter-status"><option value="active">Open + queued</option><option value="all">All statuses</option><option value="open">Open only</option><option value="queued">Queued only</option><option value="handled">Handled only</option></select>
      </div>
      <ConversationTable records={filtered} store={store} />
    </section>
    {records.length === 0 && <div className="empty-state"><h3>Your inbox is clear</h3><p>Import a CSV to start reviewing conversations.</p><Link className="btn primary" href="/imports"><Upload size={14} /> Import conversations</Link></div>}
  </div>;
}

function HistoryList({ record }: { record: Conversation }) {
  return <section className="panel"><PanelTitle title="Change history" caption="A transparent record of decisions and edits" /><div style={{ padding: '0 16px' }}>
    {record.history.length === 0 ? <div className="empty-state" style={{ padding: '23px 10px' }}><p>No changes recorded yet.</p></div> : record.history.map((entry, i) => <div className="history-item" key={`${entry.at}-${i}`}><span className="history-dot" /><div><div className="history-detail">{entry.detail}</div><div className="history-date">{displayDate(entry.at, { month: 'short', day: 'numeric', year: 'numeric', hour: 'numeric', minute: '2-digit' })}{entry.fields?.length ? ` · ${entry.fields.join(', ')}` : ''}</div></div></div>)}
  </div></section>;
}

function CorrectionDialog({ record, store, onClose }: { record: Conversation; store: Store; onClose: () => void }) {
  const [note, setNote] = useState('');
  const [fields, setFields] = useState({
    rep: record.rep, stage: record.stage, dealValue: String(record.dealValue), nextStep: record.nextStep,
    nextStepDue: record.nextStepDue, summary: record.summary, route: record.route as InboxRoute,
  });
  const set = (key: keyof typeof fields, value: string) => setFields(prev => ({ ...prev, [key]: value }));
  function submit(e: FormEvent) {
    e.preventDefault();
    const patch: Partial<EditableFields> = {
      rep: fields.rep, stage: fields.stage, dealValue: Number(fields.dealValue) || 0, nextStep: fields.nextStep,
      nextStepDue: fields.nextStepDue, summary: fields.summary, route: fields.route,
    };
    store.actions.correctRecord(record.id, patch, note.trim() || 'Manager correction to conversation details or routing.');
    onClose();
  }
  return <div className="dialog-backdrop" role="presentation" onMouseDown={e => { if (e.target === e.currentTarget) onClose(); }}><section className="dialog" role="dialog" aria-modal="true" aria-labelledby="correction-title">
    <div className="dialog-head"><div><h2 id="correction-title">Correct conversation</h2><p>Corrections stay local and are recorded in the audit history.</p></div><button className="icon-button" onClick={onClose} aria-label="Close correction form"><X size={17} /></button></div>
    <form onSubmit={submit}><div className="form-grid">
      <div className="field"><label htmlFor="edit-rep">Owner / rep</label><input className="input" id="edit-rep" value={fields.rep} onChange={e => set('rep', e.target.value)} /></div>
      <div className="field"><label htmlFor="edit-stage">Deal stage</label><input className="input" id="edit-stage" value={fields.stage} onChange={e => set('stage', e.target.value)} /></div>
      <div className="field"><label htmlFor="edit-value">Deal value (USD)</label><input className="input" id="edit-value" type="number" min="0" value={fields.dealValue} onChange={e => set('dealValue', e.target.value)} /></div>
      <div className="field"><label htmlFor="edit-route">Manager route</label><select id="edit-route" className="select" value={fields.route} onChange={e => set('route', e.target.value)}>{routeTypes.map(r => <option key={r}>{r}</option>)}</select></div>
      <div className="field full"><label htmlFor="edit-summary">Summary</label><textarea id="edit-summary" className="textarea" value={fields.summary} onChange={e => set('summary', e.target.value)} /></div>
      <div className="field full"><label htmlFor="edit-next-step">Next step</label><input id="edit-next-step" className="input" value={fields.nextStep} onChange={e => set('nextStep', e.target.value)} /></div>
      <div className="field"><label htmlFor="edit-due">Due date</label><input id="edit-due" type="date" className="input" value={fields.nextStepDue} onChange={e => set('nextStepDue', e.target.value)} /></div>
      <div className="field"><label htmlFor="edit-note">Change note</label><input id="edit-note" className="input" placeholder="Why is this changing?" value={note} onChange={e => setNote(e.target.value)} /></div>
    </div><div className="form-actions"><button type="button" className="btn" onClick={onClose}>Cancel</button><button className="btn primary" type="submit"><Check size={14} /> Save correction</button></div></form>
  </section></div>;
}

function ConversationDetail({ records, store, id }: PageProps & { id?: string }) {
  const record = records.find(item => item.id === decodeURIComponent(id ?? ''));
  const [edit, setEdit] = useState(false);
  if (!record) return <div className="page"><Link href="/" className="btn"><ArrowLeft size={14} /> Back to queue</Link><div className="empty-state"><div className="empty-icon"><CircleHelp size={20} /></div><h3>Conversation not found</h3><p>It may have been removed from this browser's local dataset.</p></div></div>;
  const acceptRoute = () => store.actions.setStatus(record.id, 'queued');
  return <div className="page">
    <PageTitle eyebrow={`Evidence review · ${record.id}`} title={record.account} description={`${record.meetingType} with ${record.contact} · ${displayDate(record.date, { month: 'long', day: 'numeric', year: 'numeric' })}`} actions={<><Link href="/" className="btn"><ArrowLeft size={14} /> Queue</Link><button className="btn" onClick={() => setEdit(true)}><Pencil size={14} /> Correct</button>{record.status === 'handled' ? <button className="btn primary" onClick={() => store.actions.setStatus(record.id, 'open')}><RotateCcw size={14} /> Reopen</button> : <><button className="btn" onClick={acceptRoute}><CheckCheck size={14} /> Accept route</button><button className="btn primary" onClick={() => store.actions.setStatus(record.id, 'handled')}><BadgeCheck size={14} /> Mark handled</button></>}</>} />
    <div className="detail-grid">
      <div className="detail-column">
        <section className="panel detail-summary"><div className="detail-summary-top"><div><h2 className="detail-account">{record.account}</h2><div className="detail-contact">{record.contact} · {record.source} · Source ID {record.externalId}</div></div><StatusPill status={record.status} /></div>
          <p style={{ fontSize: 13, lineHeight: 1.6, margin: '16px 0 0', color: '#55635c' }}>{record.summary}</p>
          <div className="detail-stats"><div className="detail-stat"><small>Deal value</small><strong>{formatMoney(record.dealValue)}</strong></div><div className="detail-stat"><small>Stage</small><strong>{record.stage}</strong></div><div className="detail-stat"><small>Owner</small><strong>{record.rep}</strong></div><div className="detail-stat"><small>Duration</small><strong>{record.durationMinutes} min</strong></div><div className="detail-stat"><small>Next step due</small><strong>{displayDate(record.nextStepDue, { month: 'short', day: 'numeric', year: 'numeric' })}</strong></div></div>
        </section>
        <section className="panel"><PanelTitle title="Source evidence" caption="Transcript excerpts that support the route" right={<span className="source-pill" style={{ background: '#f1efe5', color: '#68756d' }}>{record.transcript.length} lines</span>} />
          <div style={{ padding: '0 18px 10px' }}>{record.transcript.length === 0 ? <div className="empty-state"><MessageSquareQuote size={20} /><h3>No transcript supplied</h3><p>Imported summary and next-step fields are still available for review.</p></div> : record.transcript.map((line, i) => {
            const highlighted = record.routeEvidence.some(e => e.quote === line.text);
            return <div key={`${line.at}-${i}`} className="transcript-line"><span className="transcript-time">{line.at}</span><span className="transcript-speaker">{line.speaker}</span><span className="transcript-text">{line.text}{highlighted && <span style={{ color: '#a8792c', marginLeft: 7, fontSize: 10, fontWeight: 700 }}>ROUTE EVIDENCE</span>}</span></div>;
          })}</div>
        </section>
        <HistoryList record={record} />
      </div>
      <div className="detail-column">
        <section className="panel route-card"><PanelTitle title="Routing rationale" caption="Recommendation with evidence at the decision point" /><div style={{ padding: '0 17px 16px' }}>
          <RoutePill route={record.route} /><p className="route-reason">{record.routeReason}</p>
          {record.routeEvidence.map((e, i) => <div className="evidence" key={`${e.at}-${i}`}><blockquote>“{e.quote}”</blockquote><div className="evidence-meta"><span>{e.speaker}</span><span>·</span><span>{e.at}</span></div></div>)}
          <div className="confidence-note">Signal confidence <strong style={{ color: '#345c50' }}>{Math.round(record.confidence * 100)}%</strong> <span className="confidence"><i style={{ width: `${record.confidence * 100}%` }} /></span></div>
          {record.alternateRoute && <div className="alt-route"><strong>Alternative to consider: {record.alternateRoute}</strong><br />{record.alternateReason}</div>}
        </div></section>
        <section className="panel"><PanelTitle title="Next move" /><div style={{ padding: '15px 17px 17px' }}><div style={{ fontSize: 12, fontWeight: 700, lineHeight: 1.5 }}>{record.nextStep}</div><div className="subline" style={{ marginTop: 8 }}><Clock3 size={12} style={{ verticalAlign: 'middle', marginRight: 4 }} /> Due {displayDate(record.nextStepDue, { month: 'short', day: 'numeric', year: 'numeric' })}</div></div></section>
      </div>
    </div>
    {edit && <CorrectionDialog record={record} store={store} onClose={() => setEdit(false)} />}
  </div>;
}

function Insights({ records }: PageProps) {
  const northstar = records.find(r => r.id === 'RI-1071');
  const harborline = records.find(r => r.id === 'RI-1063');
  const mosaic = records.find(r => r.id === 'RI-1024');
  const pinecrest = records.find(r => r.id === 'RI-1059');
  return <div className="page">
    <PageTitle eyebrow="Patterns in the queue" title="Three signals worth a closer look." description="Each finding links to its source conversation and the buyer language behind it." />
    <div className="privacy-banner"><Sparkles size={15} /><span>All three findings are <strong>curated synthetic examples</strong> from the fictional seed records—not statistical conclusions about real customers.</span></div>
    <div className="finding-grid">
      <article className="panel finding">
        <span className="finding-index">SIGNAL / 01</span>
        <h2>Northstar’s $240,000 opportunity has no approved budget or buyer-dated decision.</h2>
        <p>The buyer still needs VP approval and has not named a decision date; timing may move to next quarter.</p>
        <div className="evidence"><blockquote>“I still need our VP to sign off on budget. We have not picked a decision date, so it may be next quarter.”</blockquote><div className="evidence-meta">Buyer · 12:08 · RI-1071</div></div>
        <Link className="finding-link" href={`/conversation/${encodeURIComponent(northstar?.id ?? 'RI-1071')}`}>Open Northstar source <ArrowRight size={13} /></Link>
      </article>
      <article className="panel finding">
        <span className="finding-index">SIGNAL / 02</span>
        <h2>$250,000 in next steps were past due as of Oct 23.</h2>
        <p>Harborline’s $118,000 due Oct 22 plus Mosaic’s $132,000 due Oct 21 equals $250,000 in past-due next-step value.</p>
        <div className="evidence"><blockquote>“Please send the revised proposal today. Finance is meeting Thursday and we want to decide by November first.”</blockquote><div className="evidence-meta">Harborline Finance · Buyer 08:25 · due Oct 22 · $118,000</div>
          <Link className="finding-link" href={`/conversation/${encodeURIComponent(harborline?.id ?? 'RI-1063')}`}>Open Harborline · RI-1063 <ArrowRight size={13} /></Link>
        </div>
        <div className="evidence"><blockquote>“Commercial terms look good. Our legal team will send one clause change tomorrow, then procurement can finalize.”</blockquote><div className="evidence-meta">Mosaic Commerce · Buyer 14:02 · due Oct 21 · $132,000</div>
          <Link className="finding-link" href={`/conversation/${encodeURIComponent(mosaic?.id ?? 'RI-1024')}`}>Open Mosaic · RI-1024 <ArrowRight size={13} /></Link>
        </div>
      </article>
      <article className="panel finding">
        <span className="finding-index">SIGNAL / 03</span>
        <h2>Pinecrest’s $184,000 opportunity has competitive and migration risk.</h2>
        <p>The buyer is comparing its incumbent and another alternative while migration remains a concern.</p>
        <div className="evidence"><blockquote>“We are comparing you with our incumbent and one other alternative. Migration is still a concern for the operations team.”</blockquote><div className="evidence-meta">Buyer · 19:36 · RI-1059</div></div>
        <Link className="finding-link" href={`/conversation/${encodeURIComponent(pinecrest?.id ?? 'RI-1059')}`}>Open Pinecrest source <ArrowRight size={13} /></Link>
      </article>
    </div>
    <div className="insight-note"><CircleHelp size={14} /><span>Evidence is quoted from synthetic demo transcripts. Dollar values and dates identify these examples only; they are not real customer results.</span></div>
    <div style={{ marginTop: 22 }}><Link className="btn" href="/"><Inbox size={14} /> Return to review queue</Link></div>
  </div>;
}

const sampleCsv = `id,source,date,type,duration_minutes,account,contact,rep,deal_value,stage,summary,transcript,next_step,next_step_due
TEST-900,Gong,2026-10-23T10:00:00,Discovery,24,Redwood Systems,Sam Lee,Demo Rep,54000,Discovery,"Buyer wants to validate the workflow before inviting procurement.","The workflow looks promising. We want to validate it with one operations lead next week.",Hold workflow validation with operations lead,2026-10-30`;
function Imports({ records, store }: PageProps) {
  const fileRef = useRef<HTMLInputElement>(null);
  const [csv, setCsv] = useState('');
  const [filename, setFilename] = useState('pasted-conversations.csv');
  const [committed, setCommitted] = useState('');
  const [testResult, setTestResult] = useState('');
  const preview = useMemo(() => csv.trim() ? previewCsv(csv, records) : null, [csv, records]);
  function readFile(file?: File) {
    if (!file) return;
    setFilename(file.name);
    setCommitted('');
    const reader = new FileReader();
    reader.onload = () => setCsv(String(reader.result ?? ''));
    reader.onerror = () => setCsv('');
    reader.readAsText(file);
  }
  function onFile(e: ChangeEvent<HTMLInputElement>) { readFile(e.target.files?.[0]); e.target.value = ''; }
  const commit = () => {
    if (!preview || !preview.rows.length) return;
    const run = store.actions.commitImport(preview.rows, filename);
    setCommitted(`${run.newCount} new · ${run.updatedCount} updated · ${run.unchangedCount} unchanged`);
  };
  const runRepeatTest = () => {
    if (!preview?.rows.length) return;
    store.actions.commitImport(preview.rows, `${filename} — repeat test`);
    const repeated = store.actions.commitImport(preview.rows, `${filename} — repeat test`);
    setTestResult(`Repeat test passed: second run found ${repeated.unchangedCount} unchanged row${repeated.unchangedCount === 1 ? '' : 's'}${repeated.updatedCount ? ` and ${repeated.updatedCount} update${repeated.updatedCount === 1 ? '' : 's'}` : ''}.`);
  };
  const runUpdateTest = () => {
    if (!preview?.rows.length) return;
    const baseline = store.actions.commitImport(preview.rows, `${filename} — update test baseline`);
    const testRecordId = baseline.recordIds[preview.rows[0].externalId];
    if (!testRecordId) {
      setTestResult('Update test could not find the imported source ID. Review the preview and try again.');
      return;
    }
    store.actions.correctRecord(testRecordId, { rep: 'Manager override — demo' }, 'Demo test: correct the owner before the source update.');
    const changedRows = preview.rows.map(row => ({
      ...row,
      rep: 'Updated source owner',
      dealValue: 89000,
      stage: 'Proposal',
      summary: 'Buyer requested a revised proposal today and moved the opportunity into proposal review.',
      transcript: [{ at: '00:00', speaker: 'Buyer', text: 'Please send the revised proposal today; procurement will review it after we validate the workflow.' }],
      nextStep: 'Send revised proposal and confirm procurement review',
      nextStepDue: '2026-10-23',
    }));
    const updated = store.actions.commitImport(changedRows, `${filename} — update test`);
    const after = store.actions.getRecordByExternalId(preview.rows[0].externalId);
    const preserved = after?.rep === 'Manager override — demo';
    setTestResult(`Update test: ${updated.updatedCount} source row${updated.updatedCount === 1 ? '' : 's'} refreshed; source deal value is now $89,000 and stage is Proposal. Manual owner correction ${preserved ? 'was preserved' : 'was not preserved'}. This test row remains in this browser.`);
  };
  return <div className="page">
    <PageTitle eyebrow="Browser-local data" title="Bring your call records in." description="Preview, validate and merge CSV rows by stable source ID. Nothing is uploaded." actions={<button className="btn" onClick={() => { setCsv(sampleCsv); setFilename('demo-import.csv'); setCommitted(''); }}><Plus size={14} /> Load sample CSV</button>} />
    <PrivacyBanner />
    <div className="import-layout">
      <div className="detail-column">
        <section className="panel"><PanelTitle title="Import a CSV" caption="One source ID per conversation; repeat imports merge safely." />
          <div style={{ padding: 17 }}>
            <div className="dropzone"><div className="drop-icon"><Upload size={19} /></div><strong>Choose a CSV from this device</strong><p>CSV is read in this browser only. Use the preview before committing.</p><button className="btn" type="button" onClick={() => fileRef.current?.click()}><FileSpreadsheet size={14} /> Browse files</button><input ref={fileRef} type="file" accept=".csv,text/csv" className="file-input" aria-label="Choose CSV file" onChange={onFile} /></div>
            <div className="field" style={{ marginTop: 14 }}><label htmlFor="csv-input">Or paste CSV content</label><textarea id="csv-input" className="textarea" style={{ minHeight: 132, fontFamily: 'var(--app-font-mono)', fontSize: 10 }} placeholder="external_id,account,rep,..." value={csv} onChange={e => { setCsv(e.target.value); setCommitted(''); }} /></div>
            {preview && <div className="import-preview"><div className="panel-head" style={{ padding: '12px 0', border: 0 }}><div><h3 className="panel-title">Import preview · {filename}</h3><p className="panel-caption">Rows are matched against current local records by external ID.</p></div></div>
              <div className="preview-counts"><span className="count-chip"><strong>{preview.rows.length}</strong> valid rows</span><span className="count-chip"><strong>{preview.newCount}</strong> new</span><span className="count-chip"><strong>{preview.updatedCount}</strong> update</span><span className="count-chip"><strong>{preview.unchangedCount}</strong> unchanged</span><span className="count-chip"><strong>{preview.duplicateCount}</strong> duplicate IDs</span></div>
              {preview.errors.length > 0 && <div className="error-list" role="status"><strong>{preview.errors.length} row issue{preview.errors.length === 1 ? '' : 's'}</strong>{preview.errors.map(error => <div key={`${error.row}-${error.message}`}>Row {error.row}: {error.message}</div>)}</div>}
              {preview.rows.length > 0 && <div className="table-wrap"><table className="conversation-table" style={{ minWidth: 520 }}><thead><tr><th>Source ID</th><th>Account</th><th>Rep</th><th>Deal</th></tr></thead><tbody>{preview.rows.slice(0, 6).map(row => <tr key={row.externalId}><td className="mono">{row.externalId}</td><td>{row.account}</td><td>{row.rep}</td><td>{formatMoney(row.dealValue, true)}</td></tr>)}</tbody></table>{preview.rows.length > 6 && <div className="subline" style={{ padding: 8 }}>and {preview.rows.length - 6} more preview rows</div>}</div>}
              {committed && <div className="notice success" role="status"><Check size={14} style={{ verticalAlign: 'middle', marginRight: 5 }} />Import committed: {committed}. Records are updated across the workspace.</div>}
              {testResult && <div className="notice success" role="status"><BadgeCheck size={14} style={{ verticalAlign: 'middle', marginRight: 5 }} />{testResult}</div>}
              <div style={{ display: 'flex', gap: 8, marginTop: 13 }}><button className="btn primary" disabled={!preview.rows.length} onClick={commit}><Check size={14} /> Commit valid rows</button><button className="btn" onClick={() => { setCsv(''); setCommitted(''); }}>Clear</button></div>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, marginTop: 9 }}><button className="btn small subtle" disabled={!preview.rows.length} onClick={runRepeatTest}><RotateCcw size={12} /> Test repeat import</button><button className="btn small subtle" disabled={!preview.rows.length} onClick={runUpdateTest}><Activity size={12} /> Test source update</button></div>
              <p className="field-help" style={{ marginTop: 9 }}>Tests run against valid preview rows and write their results to this browser-local dataset.</p>
            </div>}
          </div>
        </section>
        <section className="panel"><PanelTitle title="Recognized columns" caption="Header aliases are flexible; required fields are source ID and account." /><div style={{ padding: 16 }}><div className="sample-box"><strong>Required</strong> external_id, account<br /><strong>Recommended</strong> source, date, meeting_type, duration_minutes<br />contact, rep, deal_value, stage, summary, transcript<br />next_step, next_step_due</div></div></section>
      </div>
      <div className="detail-column">
        <section className="panel"><PanelTitle title="Merge behavior" caption="Stable IDs make repeat imports predictable." /><div style={{ padding: '0 17px 16px' }}>
          <div className="history-item"><span className="history-dot" /><div className="history-detail"><strong>Same ID + same source fields</strong><div className="subline">Reports unchanged; no duplicate record.</div></div></div>
          <div className="history-item"><span className="history-dot" /><div className="history-detail"><strong>Same ID + changed source fields</strong><div className="subline">Source values refresh; manager corrections are preserved.</div></div></div>
          <div className="history-item"><span className="history-dot" /><div className="history-detail"><strong>New ID</strong><div className="subline">A new conversation is created with a route assessment.</div></div></div>
          <div className="notice warning">Duplicate source IDs inside one file are collapsed to the last row. Invalid rows are skipped and listed in the preview.</div>
        </div></section>
        <section className="panel"><PanelTitle title="Import history" caption={`${store.state.importRuns.length} recent runs`} right={<button className="btn small subtle" onClick={() => store.actions.resetDemo()}><RotateCcw size={12} /> Reset demo</button>} />
          {store.state.importRuns.length === 0 ? <div className="empty-state" style={{ padding: '23px 14px' }}><div className="empty-icon"><History size={18} /></div><h3>No imports yet</h3><p>Committed CSV runs appear here for this browser.</p></div> : store.state.importRuns.map(run => <div className="run-row" key={run.id}><span className="run-file">{run.filename}</span><span className="run-date">{displayDate(run.at, { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' })}</span><span className="run-stats">{run.newCount} new · {run.updatedCount} updated · {run.unchangedCount} unchanged · {run.skippedCount} skipped</span></div>)}
        </section>
        <section className="panel"><PanelTitle title="Manual corrections" caption="Open a record to edit route, owner, summary, deal and next step." />{records.slice(0, 5).map(r => <div className="run-row" key={r.id}><div><Link href={`/conversation/${encodeURIComponent(r.id)}`} className="account-name">{r.account}</Link><span className="subline">{r.id} · {r.rep}</span></div><Link href={`/conversation/${encodeURIComponent(r.id)}`} className="btn small">Correct</Link></div>)}</section>
      </div>
    </div>
  </div>;
}

type ExportRun = { id: string; name: string; format: string; at: string; count: number; filters: string; content: string; manifest: string };
function loadExports(): ExportRun[] {
  try { return JSON.parse(localStorage.getItem('revenue-inbox:exports:v1') || '[]') as ExportRun[]; } catch { return []; }
}
function Exports({ records }: PageProps) {
  const [format, setFormat] = useState<'csv' | 'json'>('csv');
  const [from, setFrom] = useState('');
  const [to, setTo] = useState('');
  const [route, setRoute] = useState('all');
  const [status, setStatus] = useState('all');
  const [message, setMessage] = useState('');
  const [history, setHistory] = useState<ExportRun[]>(loadExports);
  const filtered = useMemo(() => records.filter(r => (!from || r.date.slice(0, 10) >= from) && (!to || r.date.slice(0, 10) <= to) && (route === 'all' || r.route === route) && (status === 'all' || r.status === status)), [records, from, to, route, status]);
  const filterLabel = `${from || 'any date'} to ${to || 'today'} · ${route === 'all' ? 'all routes' : route} · ${status === 'all' ? 'all statuses' : status}`;
  function triggerDownload(name: string, content: string, type: string) {
    const blob = new Blob([content], { type });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = name; document.body.appendChild(a); a.click(); a.remove();
    window.setTimeout(() => URL.revokeObjectURL(url), 1000);
  }
  function createExport() {
    const keys = ['id', 'externalId', 'source', 'date', 'meetingType', 'durationMinutes', 'account', 'contact', 'rep', 'dealValue', 'stage', 'summary', 'nextStep', 'nextStepDue', 'route', 'routeReason', 'confidence', 'status'];
    const recordsForExport = filtered.map(r => Object.fromEntries(keys.map(key => [key, (r as unknown as Record<string, unknown>)[key]])));
    const content = format === 'json' ? JSON.stringify(recordsForExport, null, 2) : [keys.join(','), ...recordsForExport.map(row => keys.map(key => csvEscape(row[key])).join(','))].join('\r\n');
    const at = new Date().toISOString();
    const id = `export-${Date.now()}`;
    const name = `revenue-review-${at.slice(0, 10)}.${format}`;
    const manifest = JSON.stringify({ exportId: id, generatedAt: at, format, recordCount: filtered.length, filters: filterLabel, fields: keys, localOnly: true }, null, 2);
    const entry = { id, name, format, at, count: filtered.length, filters: filterLabel, content, manifest };
    const next = [entry, ...history].slice(0, 20);
    setHistory(next);
    localStorage.setItem('revenue-inbox:exports:v1', JSON.stringify(next));
    triggerDownload(name, content, format === 'json' ? 'application/json' : 'text/csv;charset=utf-8');
    triggerDownload(`${name.replace(/\.(csv|json)$/, '')}-manifest.json`, manifest, 'application/json');
    setMessage(`${filtered.length} records exported. Data and manifest downloaded to this device.`);
  }
  const download = (entry: ExportRun, manifest = false) => triggerDownload(manifest ? `${entry.name.replace(/\.(csv|json)$/, '')}-manifest.json` : entry.name, manifest ? entry.manifest : entry.content, manifest ? 'application/json' : entry.format === 'json' ? 'application/json' : 'text/csv;charset=utf-8');
  return <div className="page">
    <PageTitle eyebrow="Take your review with you" title="Export a decision-ready file." description="Build a filtered snapshot and download its manifest alongside the data. Exports are generated in this browser." />
    <PrivacyBanner />
    <div className="export-layout">
      <section className="panel"><PanelTitle title="Configure export" caption="Choose exactly what belongs in the handoff." />
        <div className="control-grid">
          <div className="field full"><label>File format</label><div className="choice-row"><button className={`choice ${format === 'csv' ? 'selected' : ''}`} onClick={() => setFormat('csv')}><FileSpreadsheet size={14} style={{ verticalAlign: 'middle', marginRight: 6 }} />CSV</button><button className={`choice ${format === 'json' ? 'selected' : ''}`} onClick={() => setFormat('json')}><FileJson size={14} style={{ verticalAlign: 'middle', marginRight: 6 }} />JSON</button></div></div>
          <div className="field"><label htmlFor="export-from">From date</label><input type="date" className="input" id="export-from" value={from} onChange={e => setFrom(e.target.value)} /></div>
          <div className="field"><label htmlFor="export-to">Through date</label><input type="date" className="input" id="export-to" value={to} onChange={e => setTo(e.target.value)} /></div>
          <div className="field"><label htmlFor="export-route">Route</label><select id="export-route" className="select" value={route} onChange={e => setRoute(e.target.value)}><option value="all">All routes</option>{routeTypes.map(r => <option key={r}>{r}</option>)}</select></div>
          <div className="field"><label htmlFor="export-status">Status</label><select id="export-status" className="select" value={status} onChange={e => setStatus(e.target.value)}><option value="all">All statuses</option><option value="open">Open</option><option value="queued">Queued</option><option value="handled">Handled</option></select></div>
        </div>
        <div className="export-preview"><span className="export-preview-label">Ready to export</span><strong>{filtered.length} <span style={{ fontSize: 13, fontWeight: 500 }}>conversations</span></strong><small>{filterLabel}</small></div>
        {message && <div className="notice success" role="status" style={{ margin: '0 17px 14px' }}><Check size={14} style={{ verticalAlign: 'middle', marginRight: 5 }} />{message}</div>}
        <div className="export-action"><button className="btn primary" onClick={createExport}><Download size={14} /> Download {format.toUpperCase()} + manifest</button><button className="btn" onClick={() => { setFrom(''); setTo(''); setRoute('all'); setStatus('all'); setMessage(''); }}>Reset filters</button></div>
      </section>
      <section className="panel"><PanelTitle title="Export history" caption="Recent files can be downloaded again from this browser." right={<span className="mono">{history.length} FILES</span>} />
        {history.length === 0 ? <div className="empty-state"><div className="empty-icon"><ArrowDownToLine size={18} /></div><h3>No exports yet</h3><p>Your created snapshots and their manifests will appear here.</p></div> : <div className="export-history">{history.map(entry => <div className="history-export" key={entry.id}><div className="export-file-icon">{entry.format === 'csv' ? <FileSpreadsheet size={16} /> : <FileJson size={16} />}</div><div><div className="export-file-name">{entry.name}</div><div className="export-file-meta">{entry.count} records · {displayDate(entry.at, { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' })}<br />{entry.filters}</div></div><div style={{ display: 'grid', gap: 5 }}><button className="btn small" onClick={() => download(entry)}><Download size={12} /> File</button><button className="btn small subtle" onClick={() => download(entry, true)}>Manifest</button></div></div>)}</div>}
      </section>
    </div>
    <div className="insight-note"><LockKeyhole size={14} /><span>Exports contain conversation data. Store and share them according to your team's privacy practices. The app itself does not transmit them.</span></div>
  </div>;
}

function App() {
  const store = useConversationStore();
  const records = store.state.records;
  const active = records.filter(r => r.status !== 'handled').length;
  return <Shell count={active}><Switch>
    <Route path="/"><Dashboard records={records} store={store} /></Route>
    <Route path="/conversation/:id">{params => <ConversationDetail records={records} store={store} id={params.id} />}</Route>
    <Route path="/insights"><Insights records={records} store={store} /></Route>
    <Route path="/imports"><Imports records={records} store={store} /></Route>
    <Route path="/exports"><Exports records={records} store={store} /></Route>
    <Route component={NotFound} />
  </Switch></Shell>;
}

export default App;
