import { useEffect, useState } from 'react';

export type Route =
  | 'Specialist handoff'
  | 'Immediate follow-up'
  | 'Manager review'
  | 'Monitor'
  | 'Resolved';

export type ConversationStatus = 'open' | 'queued' | 'handled';
export type Sentiment = 'positive' | 'neutral' | 'concern';
export type MeetingType = 'Discovery' | 'Demo' | 'Negotiation' | 'Review' | 'Follow-up';

export interface Evidence {
  at: string;
  speaker: string;
  quote: string;
}

export interface TranscriptLine {
  at: string;
  speaker: string;
  text: string;
}

export interface SourceFields {
  externalId: string;
  source: string;
  date: string;
  meetingType: MeetingType;
  durationMinutes: number;
  account: string;
  contact: string;
  rep: string;
  dealValue: number;
  stage: string;
  summary: string;
  transcript: TranscriptLine[];
  nextStep: string;
  nextStepDue: string;
}

export type EditableFields = Pick<
  SourceFields,
  | 'date'
  | 'meetingType'
  | 'durationMinutes'
  | 'account'
  | 'contact'
  | 'rep'
  | 'dealValue'
  | 'stage'
  | 'summary'
  | 'transcript'
  | 'nextStep'
  | 'nextStepDue'
> & { route: Route };

export interface AuditEntry {
  at: string;
  action: 'imported' | 'updated' | 'corrected' | 'routed' | 'handled' | 'reopened';
  detail: string;
  fields?: string[];
}

export interface Conversation extends EditableFields {
  id: string;
  externalId: string;
  source: string;
  route: Route;
  routeReason: string;
  routeEvidence: Evidence[];
  alternateRoute: Route | null;
  alternateReason: string | null;
  confidence: number;
  status: ConversationStatus;
  manualOverrides: Partial<EditableFields>;
  sourceFields: SourceFields;
  history: AuditEntry[];
}

export interface ImportRun {
  id: string;
  at: string;
  filename: string;
  newCount: number;
  updatedCount: number;
  unchangedCount: number;
  skippedCount: number;
}

export interface InboxState {
  version: 1;
  records: Conversation[];
  importRuns: ImportRun[];
}

export interface NormalizedImport extends SourceFields {}

export interface ImportPreview {
  rows: NormalizedImport[];
  errors: { row: number; message: string }[];
  duplicateCount: number;
  newCount: number;
  updatedCount: number;
  unchangedCount: number;
}

const STORAGE_KEY = 'revenue-intelligence-inbox:v1';
const TODAY = '2026-10-23';

const transcripts = (
  lines: Array<[string, string, string]>,
): TranscriptLine[] =>
  lines.map(([at, speaker, text]) => ({ at, speaker, text }));

function sourceFields(fields: Omit<SourceFields, 'transcript'> & { transcript: TranscriptLine[] }): SourceFields {
  return structuredClone(fields);
}

function makeRecord(
  id: string,
  fields: SourceFields,
  overrides: Partial<EditableFields> = {},
): Conversation {
  const visible = { ...fields, ...overrides, route: overrides.route ?? 'Monitor' };
  const assessed = assessRoute(visible);
  return {
    id,
    ...visible,
    route: (overrides.route as Route | undefined) ?? assessed.route,
    routeReason: overrides.route
      ? `Set by manager to ${overrides.route}. Automatic assessment suggested ${assessed.route}: ${assessed.reason}`
      : assessed.reason,
    routeEvidence: assessed.evidence,
    alternateRoute: assessed.alternateRoute,
    alternateReason: assessed.alternateReason,
    confidence: assessed.confidence,
    status: 'open',
    manualOverrides: structuredClone(overrides),
    sourceFields: structuredClone(fields),
    history: [],
  };
}

export function assessRoute(fields: EditableFields): {
  route: Route;
  reason: string;
  evidence: Evidence[];
  alternateRoute: Route | null;
  alternateReason: string | null;
  confidence: number;
} {
  const buyerLines = fields.transcript.filter((line) => /\b(buyer|customer|prospect)\b/i.test(line.speaker));
  const buyerText = buyerLines.map((line) => line.text).join(' ');
  const signalText = `${fields.summary} ${buyerText}`.toLowerCase();
  // A rep's proposed next step is not buyer intent. When no buyer-side
  // transcript line exists, use the meeting summary for commitment signals.
  const commitmentText = (buyerLines.length ? buyerText : fields.summary).toLowerCase();
  const evidence: Evidence[] = [];
  const addEvidence = (patterns: RegExp[]) => {
    for (const line of buyerLines) {
      if (patterns.some((pattern) => pattern.test(line.text)) && !evidence.some((item) => item.quote === line.text)) {
        evidence.push({ at: line.at, speaker: line.speaker, quote: line.text });
      }
    }
    if (evidence.length === 0 && patterns.some((pattern) => pattern.test(fields.summary))) {
      evidence.push({ at: 'Summary', speaker: 'Meeting summary', quote: fields.summary });
    }
  };

  // Legal contract language alone is not a security/compliance handoff. A
  // genuinely overdue commitment remains actionable below.
  const specialistSignals = /\b(security|soc\s*2|dpa|baa|privacy|compliance|infosec|data processing)\b/i;
  const commercialSignals = /\b(pricing|proposal|budget|cfo|procurement|contract|decision|sign off)\b/i;
  const uncertainSignals = /\b(no date|not confirmed|not approved|next quarter|no timeline|still need|not yet)\b/i;
  const competitorSignals = /\b(competitor|alternative|instead of|switching from|incumbent)\b/i;
  const negativeSignals = /\b(blocker|blocked|concern|concerned|risk|delay|stalled|can't|cannot)\b/i;

  if (specialistSignals.test(signalText)) {
    addEvidence([specialistSignals]);
    const mixed = commercialSignals.test(signalText);
    return {
      route: 'Specialist handoff',
      reason: mixed
        ? 'A security or compliance dependency is explicit. It is the current blocker, even though the buyer also raised commercial steps.'
        : 'A security or compliance dependency needs a specialist owner before the deal can move forward.',
      evidence,
      alternateRoute: mixed ? 'Manager review' : null,
      alternateReason: mixed
        ? 'Commercial urgency also surfaced; keep the manager informed while the specialist clears the dependency.'
        : null,
      confidence: mixed ? 0.68 : 0.86,
    };
  }

  const urgentDue = fields.nextStepDue && fields.nextStepDue <= TODAY;
  const explicitCommitment = /\b(send|share|deliver|book|schedule|confirm|by friday|today|tomorrow)\b/i.test(commitmentText);
  if (urgentDue || explicitCommitment) {
    addEvidence([/\b(by friday|today|tomorrow|send|share|deliver|book|schedule|confirm|proposal)\b/i]);
    return {
      route: 'Immediate follow-up',
      reason: urgentDue
        ? `The next step is due ${fields.nextStepDue}; act on it before the opportunity cools.`
        : 'The buyer named a concrete next action, so a prompt owner response is warranted.',
      evidence,
      alternateRoute: null,
      alternateReason: null,
      confidence: urgentDue ? 0.91 : 0.79,
    };
  }

  const highValue = fields.dealValue >= 100000;
  const uncertain = uncertainSignals.test(signalText);
  const competitor = competitorSignals.test(signalText);
  const concern = negativeSignals.test(signalText) || fields.stage.toLowerCase().includes('stalled');
  if ((highValue && uncertain) || competitor || concern) {
    addEvidence([uncertainSignals, competitorSignals, negativeSignals].filter(
      (pattern) => pattern.test(signalText),
    ));
    const reason = competitor
      ? 'A competitor or alternative is in the conversation; a manager should review the deal plan.'
      : highValue && uncertain
        ? 'A high-value opportunity has no confirmed budget or decision date.'
        : 'A blocker or risk signal needs a manager to decide the next intervention.';
    return {
      route: 'Manager review',
      reason,
      evidence,
      alternateRoute: highValue && uncertain ? 'Monitor' : null,
      alternateReason: highValue && uncertain
        ? 'If the timing is intentionally early-stage, monitor for a buyer-confirmed milestone instead.'
        : null,
      confidence: highValue && uncertain ? 0.64 : 0.77,
    };
  }

  return {
    route: 'Monitor',
    reason: 'No hard blocker or time-sensitive commitment was found. Keep the next milestone visible and recheck after it.',
    evidence: (buyerLines.length ? buyerLines.slice(0, 1) : fields.transcript.slice(0, 1)).map((line) => ({
      at: line.at,
      speaker: line.speaker,
      quote: line.text,
    })),
    alternateRoute: null,
    alternateReason: null,
    confidence: 0.73,
  };
}

function buildDemoState(): InboxState {
  const records = [
    makeRecord('RI-1084', sourceFields({
      externalId: 'RI-1084',
      source: 'Gong',
      date: '2026-10-23T09:14:00',
      meetingType: 'Review',
      durationMinutes: 38,
      account: 'Acme Cloud',
      contact: 'Arjun Mehta',
      rep: 'Kavya Rao',
      dealValue: 126000,
      stage: 'Security review',
      summary: 'Security is blocking the evaluation; pricing is headed to the CFO once the packet is cleared.',
      transcript: transcripts([
        ['04:12', 'Buyer', 'Security review is the blocker now. Send the SOC 2 report and our DPA by Friday; pricing goes to our CFO after that.'],
        ['05:04', 'Rep', 'I will send the security packet today and coordinate an introduction to our solutions engineer.'],
      ]),
      nextStep: 'Send SOC 2 and DPA; book a security specialist review',
      nextStepDue: '2026-10-23',
    })),
    makeRecord('RI-1071', sourceFields({
      externalId: 'RI-1071',
      source: 'Zoom',
      date: '2026-10-22T15:30:00',
      meetingType: 'Discovery',
      durationMinutes: 44,
      account: 'Northstar Data',
      contact: 'Isha Kapoor',
      rep: 'Dev Shah',
      dealValue: 240000,
      stage: 'Evaluation',
      summary: 'Large opportunity with interest but no approved budget or dated decision.',
      transcript: transcripts([
        ['12:08', 'Buyer', 'I still need our VP to sign off on budget. We have not picked a decision date, so it may be next quarter.'],
        ['15:42', 'Rep', 'Would a short checkpoint next week help us confirm the internal path?'],
      ]),
      nextStep: 'Confirm executive sponsor and decision milestone',
      nextStepDue: '2026-10-29',
    })),
    makeRecord('RI-1063', sourceFields({
      externalId: 'RI-1063',
      source: 'Gong',
      date: '2026-10-21T11:00:00',
      meetingType: 'Negotiation',
      durationMinutes: 31,
      account: 'Harborline Finance',
      contact: 'Mina Das',
      rep: 'Kavya Rao',
      dealValue: 118000,
      stage: 'Proposal',
      summary: 'Buyer asked for the revised proposal before their finance review.',
      transcript: transcripts([
        ['08:25', 'Buyer', 'Please send the revised proposal today. Finance is meeting Thursday and we want to decide by November first.'],
        ['09:02', 'Rep', 'I will send the updated version this afternoon and confirm it arrived.'],
      ]),
      nextStep: 'Send revised proposal and confirm finance review',
      nextStepDue: '2026-10-22',
    })),
    makeRecord('RI-1059', sourceFields({
      externalId: 'RI-1059',
      source: 'Zoom',
      date: '2026-10-20T13:10:00',
      meetingType: 'Demo',
      durationMinutes: 52,
      account: 'Pinecrest Health',
      contact: 'Noah Williams',
      rep: 'Dev Shah',
      dealValue: 184000,
      stage: 'Technical evaluation',
      summary: 'The incumbent is being compared with two alternatives; migration risk is unresolved.',
      transcript: transcripts([
        ['19:36', 'Buyer', 'We are comparing you with our incumbent and one other alternative. Migration is still a concern for the operations team.'],
        ['22:09', 'Rep', 'I can set up a migration workshop with your technical lead before the next review.'],
      ]),
      nextStep: 'Agree on migration workshop attendees',
      nextStepDue: '2026-10-27',
    })),
    makeRecord('RI-1052', sourceFields({
      externalId: 'RI-1052',
      source: 'Gong',
      date: '2026-10-20T10:45:00',
      meetingType: 'Follow-up',
      durationMinutes: 26,
      account: 'Atlas Retail',
      contact: 'Priya Nair',
      rep: 'Omar Khan',
      dealValue: 64000,
      stage: 'Evaluation',
      summary: 'Buyer agreed to bring the data lead to the next working session.',
      transcript: transcripts([
        ['11:02', 'Buyer', 'The data lead can join next Tuesday. We want to validate two workflows before involving procurement.'],
      ]),
      nextStep: 'Hold workflow validation with data lead',
      nextStepDue: '2026-10-27',
    })),
    makeRecord('RI-1047', sourceFields({
      externalId: 'RI-1047',
      source: 'Zoom',
      date: '2026-10-17T16:20:00',
      meetingType: 'Review',
      durationMinutes: 35,
      account: 'Brightpath Systems',
      contact: 'Luis Ortega',
      rep: 'Kavya Rao',
      dealValue: 92000,
      stage: 'Proposal',
      summary: 'A proposal was reviewed; the buyer asked to clarify implementation ownership.',
      transcript: transcripts([
        ['16:04', 'Buyer', 'The proposal is close. We need to know who owns the first two weeks of implementation.'],
      ]),
      nextStep: 'Clarify implementation plan and owner',
      nextStepDue: '2026-10-24',
    })),
    makeRecord('RI-1038', sourceFields({
      externalId: 'RI-1038',
      source: 'Gong',
      date: '2026-10-16T09:30:00',
      meetingType: 'Discovery',
      durationMinutes: 41,
      account: 'Copperleaf Logistics',
      contact: 'Rhea Banerjee',
      rep: 'Omar Khan',
      dealValue: 78000,
      stage: 'Discovery',
      summary: 'Workflow problem is clear, but no internal owner for the evaluation has been named.',
      transcript: transcripts([
        ['07:18', 'Buyer', 'The team loses hours reconciling dispatch changes. I need to check who can own a pilot internally.'],
      ]),
      nextStep: 'Name pilot owner and confirm success measure',
      nextStepDue: '2026-10-28',
    })),
    makeRecord('RI-1024', sourceFields({
      externalId: 'RI-1024',
      source: 'Zoom',
      date: '2026-10-15T14:00:00',
      meetingType: 'Negotiation',
      durationMinutes: 29,
      account: 'Mosaic Commerce',
      contact: 'Aarav Singh',
      rep: 'Dev Shah',
      dealValue: 132000,
      stage: 'Contracting',
      summary: 'Commercial terms were agreed; legal requested one final clause revision.',
      transcript: transcripts([
        ['14:02', 'Buyer', 'Commercial terms look good. Our legal team will send one clause change tomorrow, then procurement can finalize.'],
      ]),
      nextStep: 'Review clause change and confirm procurement handoff',
      nextStepDue: '2026-10-21',
    })),
  ];

  return {
    version: 1,
    records,
    importRuns: [],
  };
}

const DEMO_STATE = buildDemoState();
const listeners = new Set<() => void>();

function loadState(): InboxState {
  if (typeof window === 'undefined') return DEMO_STATE;
  const saved = window.localStorage.getItem(STORAGE_KEY);
  if (!saved) return DEMO_STATE;
  try {
    const parsed = JSON.parse(saved) as InboxState;
    if (parsed.version === 1 && Array.isArray(parsed.records)) {
      // Reassess imported/demo records with the current routing rules when an
      // older browser-local snapshot is reopened. Explicit manager overrides
      // remain authoritative and are labeled as such in the displayed reason.
      const records = parsed.records.map((record) => {
        const assessed = assessRoute(record);
        const managerRoute = record.manualOverrides?.route;
        return {
          ...record,
          route: managerRoute ?? assessed.route,
          routeReason: managerRoute
            ? `Set by manager to ${managerRoute}. Automatic assessment suggested ${assessed.route}: ${assessed.reason}`
            : assessed.reason,
          routeEvidence: assessed.evidence,
          alternateRoute: assessed.alternateRoute,
          alternateReason: assessed.alternateReason,
          confidence: assessed.confidence,
        };
      });
      return { ...parsed, records };
    }
  } catch {
    // An unreadable local snapshot should not prevent a fresh demo from opening.
  }
  return DEMO_STATE;
}

function persist(next: InboxState) {
  window.localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
  listeners.forEach((listener) => listener());
}

export function useConversationStore() {
  const [state, setState] = useState<InboxState>(() => loadState());
  useEffect(() => {
    const refresh = () => setState(loadState());
    listeners.add(refresh);
    window.addEventListener('storage', refresh);
    return () => {
      listeners.delete(refresh);
      window.removeEventListener('storage', refresh);
    };
  }, []);

  function commitImport(rows: NormalizedImport[], filename: string) {
    const current = loadState();
    const byExternalId = new Map(current.records.map((record) => [record.externalId, record]));
    let newCount = 0;
    let updatedCount = 0;
    let unchangedCount = 0;
    const nextRecords = [...current.records];
    const indices = new Map(nextRecords.map((record, index) => [record.externalId, index]));
    const now = new Date().toISOString();

    for (const incoming of rows) {
      const prior = byExternalId.get(incoming.externalId);
      if (!prior) {
        const created = makeRecord(`IMP-${slug(incoming.externalId)}`, incoming);
        created.history.unshift({ at: now, action: 'imported', detail: `Imported from ${filename}.` });
        indices.set(created.externalId, nextRecords.length);
        nextRecords.push(created);
        byExternalId.set(created.externalId, created);
        newCount += 1;
        continue;
      }

      if (JSON.stringify(prior.sourceFields) === JSON.stringify(incoming)) {
        unchangedCount += 1;
        continue;
      }

      const merged = makeRecord(prior.id, incoming, prior.manualOverrides);
      merged.status = prior.status;
      merged.history = [
        { at: now, action: 'updated' as const, detail: `Source values refreshed from ${filename}; manual corrections were preserved.` },
        ...prior.history,
      ].slice(0, 30);
      nextRecords[indices.get(prior.externalId)!] = merged;
      byExternalId.set(merged.externalId, merged);
      updatedCount += 1;
    }

    const run: ImportRun = {
      id: `run-${Date.now()}`,
      at: now,
      filename,
      newCount,
      updatedCount,
      unchangedCount,
      skippedCount: 0,
    };
    persist({ ...current, records: nextRecords, importRuns: [run, ...current.importRuns].slice(0, 20) });
    return {
      ...run,
      recordIds: Object.fromEntries(
        rows.map((row) => [row.externalId, byExternalId.get(row.externalId)?.id ?? '']),
      ),
    };
  }

  function getRecordByExternalId(externalId: string) {
    return loadState().records.find((record) => record.externalId === externalId);
  }

  function correctRecord(id: string, patch: Partial<EditableFields>, note: string) {
    const current = loadState();
    const now = new Date().toISOString();
    const records = current.records.map((record) => {
      if (record.id !== id) return record;
      const manualOverrides = { ...record.manualOverrides, ...patch };
      const visible = { ...record.sourceFields, ...manualOverrides, route: manualOverrides.route ?? record.route };
      const assessed = assessRoute(visible);
      const nextRoute = manualOverrides.route ?? assessed.route;
      const fields = Object.keys(patch);
      return {
        ...record,
        ...visible,
        route: nextRoute,
         routeReason: manualOverrides.route
           ? `Set by manager to ${manualOverrides.route}. Automatic assessment suggested ${assessed.route}: ${assessed.reason}`
           : assessed.reason,
        routeEvidence: assessed.evidence,
        alternateRoute: assessed.alternateRoute,
        alternateReason: assessed.alternateReason,
        confidence: assessed.confidence,
        manualOverrides,
        history: [
          { at: now, action: 'corrected' as const, detail: note || `Corrected ${fields.join(', ')}.`, fields },
          ...record.history,
        ].slice(0, 30),
      };
    });
    persist({ ...current, records });
  }

  function setStatus(id: string, status: ConversationStatus) {
    const current = loadState();
    const now = new Date().toISOString();
    const records = current.records.map((record) => record.id === id
      ? {
          ...record,
          status,
          history: [
            {
              at: now,
              action: status === 'handled' ? 'handled' as const : status === 'queued' ? 'routed' as const : 'reopened' as const,
              detail: status === 'handled' ? 'Marked as handled.' : status === 'queued' ? `Queued for ${record.route}.` : 'Reopened for review.',
            },
            ...record.history,
          ].slice(0, 30),
        }
      : record);
    persist({ ...current, records });
  }

  function resetDemo() {
    persist(buildDemoState());
  }

  return {
    state,
    actions: {
      commitImport,
      getRecordByExternalId,
      correctRecord,
      setStatus,
      resetDemo,
    },
  };
}

function slug(value: string) {
  return value.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 48) || 'record';
}

function parseCsvRows(input: string): string[][] {
  const rows: string[][] = [];
  let row: string[] = [];
  let cell = '';
  let quoted = false;
  for (let i = 0; i < input.length; i += 1) {
    const char = input[i];
    if (char === '"') {
      if (quoted && input[i + 1] === '"') {
        cell += '"';
        i += 1;
      } else {
        quoted = !quoted;
      }
    } else if (char === ',' && !quoted) {
      row.push(cell.trim());
      cell = '';
    } else if ((char === '\n' || char === '\r') && !quoted) {
      if (char === '\r' && input[i + 1] === '\n') i += 1;
      row.push(cell.trim());
      if (row.some(Boolean)) rows.push(row);
      row = [];
      cell = '';
    } else {
      cell += char;
    }
  }
  row.push(cell.trim());
  if (row.some(Boolean)) rows.push(row);
  return rows;
}

const HEADER_ALIASES: Record<string, string[]> = {
  externalId: ['externalid', 'external_id', 'id', 'source_id', 'call_id', 'meeting_id'],
  source: ['source', 'platform', 'system'],
  date: ['date', 'meeting_date', 'call_date', 'created_at'],
  meetingType: ['meetingtype', 'meeting_type', 'type'],
  durationMinutes: ['durationminutes', 'duration_minutes', 'duration', 'duration_min'],
  account: ['account', 'company', 'company_name'],
  contact: ['contact', 'buyer', 'contact_name'],
  rep: ['rep', 'owner', 'sales_rep', 'account_executive'],
  dealValue: ['dealvalue', 'deal_value', 'amount', 'pipeline_value', 'amount_usd'],
  stage: ['stage', 'deal_stage'],
  summary: ['summary', 'meeting_summary', 'notes'],
  transcript: ['transcript', 'transcript_text'],
  nextStep: ['nextstep', 'next_step', 'action_item'],
  nextStepDue: ['nextstepdue', 'next_step_due', 'due_date'],
};

function normalizedHeader(value: string) {
  return value.toLowerCase().replace(/[^a-z0-9]/g, '');
}

export function previewCsv(input: string, existing: Conversation[]): ImportPreview {
  const raw = parseCsvRows(input);
  if (raw.length < 2) {
    return { rows: [], errors: [{ row: 1, message: 'The CSV needs a header row and at least one data row.' }], duplicateCount: 0, newCount: 0, updatedCount: 0, unchangedCount: 0 };
  }
  const headers = raw[0].map(normalizedHeader);
  const columns = Object.fromEntries(
    Object.entries(HEADER_ALIASES).map(([field, aliases]) => [
      field,
      headers.findIndex((header) => aliases.some((alias) => normalizedHeader(alias) === header)),
    ]),
  ) as Record<string, number>;
  const get = (cells: string[], field: string) => {
    const index = columns[field];
    return index === undefined || index < 0 ? '' : (cells[index] ?? '').trim();
  };
  const errors: ImportPreview['errors'] = [];
  const deduped = new Map<string, NormalizedImport>();
  let duplicateCount = 0;
  const typeMap: Record<string, MeetingType> = {
    discovery: 'Discovery', demo: 'Demo', negotiation: 'Negotiation', review: 'Review', 'follow-up': 'Follow-up', followup: 'Follow-up',
  };

  for (let i = 1; i < raw.length; i += 1) {
    const cells = raw[i];
    const externalId = get(cells, 'externalId');
    const account = get(cells, 'account');
    if (!externalId || !account) {
      errors.push({ row: i + 1, message: 'Source ID and account are required; this row was skipped.' });
      continue;
    }
    const transcriptText = get(cells, 'transcript');
    const summary = get(cells, 'summary') || transcriptText.slice(0, 240) || 'No summary provided.';
    const dateInput = get(cells, 'date');
    const parsedDate = dateInput ? new Date(dateInput) : new Date();
    if (Number.isNaN(parsedDate.getTime())) {
      errors.push({ row: i + 1, message: 'Date could not be read; this row was skipped.' });
      continue;
    }
    const meetingType = typeMap[get(cells, 'meetingType').toLowerCase()] ?? 'Review';
    const durationRaw = Number(get(cells, 'durationMinutes')) || 0;
    const amountRaw = Number(get(cells, 'dealValue').replace(/[$,\s]/g, '')) || 0;
    const date = parsedDate.toISOString();
    const row: NormalizedImport = {
      externalId,
      source: get(cells, 'source') || 'CSV import',
      date,
      meetingType,
      durationMinutes: Math.max(0, durationRaw),
      account,
      contact: get(cells, 'contact') || 'Unknown contact',
      rep: get(cells, 'rep') || 'Unassigned',
      dealValue: Math.max(0, amountRaw),
      stage: get(cells, 'stage') || 'Discovery',
      summary,
      transcript: transcriptText ? [{
        at: '00:00',
        speaker: 'Imported transcript',
        text: transcriptText,
      }] : [],
      nextStep: get(cells, 'nextStep') || 'Review and assign a next step',
      nextStepDue: get(cells, 'nextStepDue'),
    };
    if (deduped.has(externalId)) duplicateCount += 1;
    deduped.set(externalId, row);
  }

  const recordsBySource = new Map(existing.map((record) => [record.externalId, record]));
  let newCount = 0;
  let updatedCount = 0;
  let unchangedCount = 0;
  const rows = [...deduped.values()];
  for (const row of rows) {
    const prior = recordsBySource.get(row.externalId);
    if (!prior) newCount += 1;
    else if (JSON.stringify(prior.sourceFields) === JSON.stringify(row)) unchangedCount += 1;
    else updatedCount += 1;
  }

  return { rows, errors, duplicateCount, newCount, updatedCount, unchangedCount };
}

export function formatMoney(value: number, compact = false) {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    maximumFractionDigits: 0,
    notation: compact ? 'compact' : 'standard',
  }).format(value);
}

export function displayDate(value: string, options?: Intl.DateTimeFormatOptions) {
  if (!value) return 'Not set';
  const date = new Date(value.length === 10 ? `${value}T12:00:00` : value);
  if (Number.isNaN(date.getTime())) return 'Not set';
  return new Intl.DateTimeFormat('en-US', options ?? { month: 'short', day: 'numeric' }).format(date);
}

export function csvEscape(value: unknown) {
  const text = String(value ?? '');
  return /[",\n\r]/.test(text) ? `"${text.replace(/"/g, '""')}"` : text;
}
