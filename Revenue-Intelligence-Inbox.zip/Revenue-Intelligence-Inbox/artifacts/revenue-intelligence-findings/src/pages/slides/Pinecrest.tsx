export default function Pinecrest() {
  return (
    <div className="relative h-screen w-screen overflow-hidden bg-background text-foreground font-body">
      <div className="absolute left-0 top-0 h-[0.8vh] w-[20vw] bg-accent" />
      <main className="relative flex h-full flex-col px-[6vw] py-[7vh]">
        <h1 className="max-w-[83vw] text-[3.55vw] font-display font-bold leading-[1.1] tracking-[-0.045em] text-primary">
          Finding 3 · Pinecrest is comparing alternatives
        </h1>
        <div className="mt-[7vh] grid flex-1 grid-cols-[.85fr_1.15fr] items-center gap-[4vw]">
          <section className="flex h-[58vh] flex-col justify-center border-y-[0.7vh] border-accent py-[3vh]">
            <p className="text-[3vw] font-display font-bold leading-[1.2] tracking-[-0.03em] text-primary">
              $184,000 opportunity · RI-1059 · Technical evaluation
            </p>
            <p className="mt-[3vh] text-[1.75vw] leading-[1.35] text-muted">Evidence: Oct 20, 2026 call, 19:36</p>
          </section>
          <section className="flex flex-col justify-center pl-[1vw]">
            <p className="text-[1.7vw] font-bold uppercase tracking-[0.12em] text-muted">Buyer</p>
            <blockquote className="mt-[1.5vh] text-[2.65vw] font-medium leading-[1.3] tracking-[-0.025em] text-primary">
              “We are comparing you with our incumbent and one other alternative. Migration is still a concern for the operations team.”
            </blockquote>
            <p className="mt-[5vh] max-w-[55vw] text-[2vw] font-semibold leading-[1.35] text-foreground">
              Manager action: agree on a migration workshop and the buyer’s comparison criteria
            </p>
          </section>
        </div>
      </main>
    </div>
  );
}
