export default function AcmeDecision() {
  return (
    <div className="relative h-screen w-screen overflow-hidden bg-background text-foreground font-body">
      <div className="absolute left-0 top-0 h-[0.8vh] w-[20vw] bg-accent" />
      <main className="relative flex h-full flex-col px-[6vw] py-[7vh]">
        <h1 className="max-w-[86vw] text-[3.55vw] font-display font-bold leading-[1.1] tracking-[-0.045em] text-primary">
          Decision · Route the blocker, not the biggest number
        </h1>
        <p className="mt-[2.5vh] text-[2vw] font-semibold leading-[1.3] text-muted">Acme Cloud · $126,000 · RI-1084</p>
        <div className="mt-[3.5vh] grid flex-1 grid-cols-[1fr_1fr] gap-[4vw]">
          <section className="flex flex-col justify-center border-l-[0.7vw] border-accent pl-[2.2vw]">
            <p className="text-[1.7vw] font-bold uppercase tracking-[0.12em] text-muted">Buyer</p>
            <blockquote className="mt-[1.5vh] text-[2.2vw] font-medium leading-[1.34] tracking-[-0.02em] text-primary">
              “Security review is the blocker now. Send the SOC 2 report and our DPA by Friday; pricing goes to our CFO after that.”
            </blockquote>
          </section>
          <section className="flex flex-col justify-center gap-[2.3vh]">
            <p className="border-b border-[#dcd9cc] pb-[2.2vh] text-[2vw] font-semibold leading-[1.35] text-primary">
              Selected: Specialist handoff; keep the manager informed on pricing
            </p>
            <p className="border-b border-[#dcd9cc] pb-[2.2vh] text-[2vw] leading-[1.35] text-muted">
              Considered and rejected: Manager review as the primary route solely due to deal size and CFO involvement
            </p>
            <p className="text-[2vw] font-medium leading-[1.35] text-foreground">
              Why: security documentation is the stated blocker; the specialist clears the gate first
            </p>
          </section>
        </div>
      </main>
    </div>
  );
}
