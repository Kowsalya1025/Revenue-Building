export default function Northstar() {
  return (
    <div className="relative h-screen w-screen overflow-hidden bg-background text-foreground font-body">
      <div className="absolute left-0 top-0 h-[0.8vh] w-[20vw] bg-accent" />
      <main className="relative flex h-full flex-col px-[6vw] py-[7vh]">
        <h1 className="max-w-[82vw] text-[3.55vw] font-display font-bold leading-[1.1] tracking-[-0.045em] text-primary">
          Finding 1 · Northstar has no dated buying decision
        </h1>
        <div className="mt-[6vh] grid flex-1 grid-cols-[.8fr_1.2fr] items-center gap-[4vw]">
          <section className="flex h-[56vh] flex-col justify-center bg-primary px-[3vw] py-[4vh] text-[#f8f6f0]">
            <p className="text-[5.4vw] font-display font-extrabold leading-[1.02] tracking-[-0.06em]">$240,000</p>
            <p className="mt-[2vh] text-[2vw] font-medium leading-[1.35]">opportunity · RI-1071 · Evaluation</p>
            <div className="mt-[5vh] h-[0.7vh] w-[6vw] bg-accent" />
          </section>
          <section className="flex flex-col justify-center">
            <p className="text-[1.7vw] font-bold uppercase tracking-[0.12em] text-muted">Buyer</p>
            <blockquote className="mt-[1.3vh] text-[2.4vw] font-medium leading-[1.32] tracking-[-0.02em] text-primary">
              “I still need our VP to sign off on budget. We have not picked a decision date, so it may be next quarter.”
            </blockquote>
            <p className="mt-[3vh] text-[1.7vw] leading-[1.35] text-muted">Evidence: Oct 22, 2026 call, 12:08</p>
            <p className="mt-[4vh] max-w-[55vw] text-[2vw] font-semibold leading-[1.35] text-foreground">
              Manager action: confirm executive sponsor, approved budget, and a decision milestone
            </p>
          </section>
        </div>
      </main>
    </div>
  );
}
