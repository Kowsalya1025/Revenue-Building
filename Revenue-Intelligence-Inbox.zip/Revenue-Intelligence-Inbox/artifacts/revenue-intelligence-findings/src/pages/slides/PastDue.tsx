export default function PastDue() {
  return (
    <div className="relative h-screen w-screen overflow-hidden bg-background text-foreground font-body">
      <div className="absolute right-0 top-0 h-[0.8vh] w-[20vw] bg-accent" />
      <main className="relative flex h-full flex-col px-[6vw] py-[7vh]">
        <h1 className="max-w-[82vw] text-[3.55vw] font-display font-bold leading-[1.1] tracking-[-0.045em] text-primary">
          Finding 2 · Two follow-ups are past due
        </h1>
        <p className="mt-[4vh] text-[3.2vw] font-display font-extrabold leading-none tracking-[-0.05em] text-primary">
          $250,000 combined pipeline · due Oct 21–22
        </p>
        <div className="mt-[4vh] grid flex-1 grid-cols-2 gap-[2vw]">
          <section className="flex flex-col justify-between border border-[#dcd9cc] bg-surface p-[2vw]">
            <p className="text-[1.65vw] font-semibold leading-[1.3] text-muted">
              Harborline Finance · $118,000 · RI-1063 · due Oct 22:
            </p>
            <blockquote className="mt-[2vh] text-[2vw] font-medium leading-[1.34] text-primary">
              “Please send the revised proposal today. Finance is meeting Thursday and we want to decide by November first.”
            </blockquote>
          </section>
          <section className="flex flex-col justify-between border border-[#dcd9cc] bg-surface p-[2vw]">
            <p className="text-[1.65vw] font-semibold leading-[1.3] text-muted">
              Mosaic Commerce · $132,000 · RI-1024 · due Oct 21:
            </p>
            <blockquote className="mt-[2vh] text-[2vw] font-medium leading-[1.34] text-primary">
              “Our legal team will send one clause change tomorrow, then procurement can finalize.”
            </blockquote>
          </section>
        </div>
        <p className="mt-[3vh] text-[2vw] font-semibold leading-[1.3] text-foreground">
          Manager action: confirm both deliverables landed and reset the next date
        </p>
      </main>
    </div>
  );
}
