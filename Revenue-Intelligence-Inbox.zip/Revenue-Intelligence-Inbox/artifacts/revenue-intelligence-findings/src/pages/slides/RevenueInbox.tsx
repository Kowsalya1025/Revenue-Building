export default function RevenueInbox() {
  return (
    <div className="relative h-screen w-screen overflow-hidden bg-background text-foreground font-body">
      <div className="absolute inset-y-0 right-0 w-[47vw] bg-primary" />
      <div className="absolute left-0 top-0 h-[1.2vh] w-[61vw] bg-accent" />
      <main className="relative grid h-full grid-cols-[1.1fr_.9fr] items-center gap-[4vw] px-[6vw] py-[8vh]">
        <section className="flex h-full flex-col justify-center pr-[1vw]">
          <h1 className="max-w-[53vw] text-[6.1vw] font-display font-extrabold leading-[1.03] tracking-[-0.055em] text-primary">
            Revenue Intelligence Inbox
          </h1>
          <p className="mt-[2.4vh] max-w-[44vw] text-[2.3vw] font-medium leading-[1.32] text-muted">
            A sales manager’s review queue, tested on eight fictional meetings.
          </p>
          <p className="mt-[5vh] max-w-[43vw] text-[2vw] leading-[1.35] text-foreground">
            Every finding links to its source conversation
          </p>
          <p className="mt-[1.4vh] text-[1.65vw] text-muted">Oct 15–23, 2026</p>
        </section>
        <section className="flex h-full flex-col justify-center pl-[2vw] text-[#f8f6f0]">
          <div className="border-b border-white/25 pb-[3vh]">
            <p className="text-[8vw] font-display font-extrabold leading-none tracking-[-0.06em]">8</p>
            <p className="mt-[1.5vh] text-[2vw] font-medium">synthetic conversations</p>
          </div>
          <div className="pt-[3vh]">
            <p className="text-[6.3vw] font-display font-extrabold leading-[1.05] tracking-[-0.06em]">$1.034M</p>
            <p className="mt-[1.2vh] text-[2vw] font-medium">illustrative pipeline</p>
          </div>
          <div className="mt-[8vh] h-[0.7vh] w-[8vw] bg-accent" />
        </section>
      </main>
    </div>
  );
}
